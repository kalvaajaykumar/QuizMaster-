import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Trophy } from "lucide-react"

export default function LeaderboardPage() {
  return (
    <div className="container py-10">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold">Leaderboard</h1>
          <p className="text-muted-foreground">See how you rank against other quiz takers</p>
        </div>

        <div className="flex flex-col gap-4 md:flex-row md:items-end">
          <div className="flex-1 space-y-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search users..." className="w-full pl-8" />
            </div>
          </div>
        </div>

        <Tabs defaultValue="global" className="w-full">
          <TabsList className="grid w-full grid-cols-3 md:w-auto">
            <TabsTrigger value="global">Global</TabsTrigger>
            <TabsTrigger value="friends">Friends</TabsTrigger>
            <TabsTrigger value="by-category">By Category</TabsTrigger>
          </TabsList>

          <TabsContent value="global" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Global Rankings</CardTitle>
                <CardDescription>Top performers across all quizzes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div className="flex justify-between items-center">
                    <div className="grid grid-cols-[40px_1fr] sm:grid-cols-[40px_1fr_1fr_1fr] gap-4 w-full">
                      <div className="font-medium">#</div>
                      <div className="font-medium">User</div>
                      <div className="font-medium hidden sm:block">Quizzes Completed</div>
                      <div className="font-medium hidden sm:block">Avg. Score</div>
                    </div>
                    <div className="font-medium">Points</div>
                  </div>

                  {leaderboardData.map((user, index) => (
                    <div key={user.id} className="flex justify-between items-center">
                      <div className="grid grid-cols-[40px_1fr] sm:grid-cols-[40px_1fr_1fr_1fr] gap-4 w-full">
                        <div className="flex items-center justify-center">
                          {index < 3 ? (
                            <Trophy
                              className={`h-5 w-5 ${
                                index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-600"
                              }`}
                            />
                          ) : (
                            <span className="text-muted-foreground">{index + 1}</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={user.avatar} alt={user.name} />
                            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{user.name}</span>
                        </div>
                        <div className="hidden sm:flex items-center">{user.quizzesCompleted}</div>
                        <div className="hidden sm:flex items-center">{user.averageScore}%</div>
                      </div>
                      <div className="font-bold">{user.points}</div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-center mt-8">
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" disabled>
                      &lt;
                    </Button>
                    <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">
                      1
                    </Button>
                    <Button variant="outline" size="sm">
                      2
                    </Button>
                    <Button variant="outline" size="sm">
                      3
                    </Button>
                    <Button variant="outline" size="icon">
                      &gt;
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="friends" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Friends Rankings</CardTitle>
                <CardDescription>See how you compare to your friends</CardDescription>
              </CardHeader>
              <CardContent className="flex items-center justify-center h-60">
                <div className="text-center text-muted-foreground">
                  <p>Connect with friends to see their rankings</p>
                  <Button className="mt-4">Find Friends</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="by-category" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Rankings by Category</CardTitle>
                <CardDescription>Top performers in specific quiz categories</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="science">
                  <TabsList className="mb-4">
                    <TabsTrigger value="science">Science</TabsTrigger>
                    <TabsTrigger value="history">History</TabsTrigger>
                    <TabsTrigger value="geography">Geography</TabsTrigger>
                    <TabsTrigger value="entertainment">Entertainment</TabsTrigger>
                  </TabsList>

                  <TabsContent value="science">
                    <div className="space-y-8">
                      <div className="flex justify-between items-center">
                        <div className="grid grid-cols-[40px_1fr] sm:grid-cols-[40px_1fr_1fr] gap-4 w-full">
                          <div className="font-medium">#</div>
                          <div className="font-medium">User</div>
                          <div className="font-medium hidden sm:block">Quizzes Completed</div>
                        </div>
                        <div className="font-medium">Score</div>
                      </div>

                      {scienceCategoryData.map((user, index) => (
                        <div key={user.id} className="flex justify-between items-center">
                          <div className="grid grid-cols-[40px_1fr] sm:grid-cols-[40px_1fr_1fr] gap-4 w-full">
                            <div className="flex items-center justify-center">
                              {index < 3 ? (
                                <Trophy
                                  className={`h-5 w-5 ${
                                    index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-600"
                                  }`}
                                />
                              ) : (
                                <span className="text-muted-foreground">{index + 1}</span>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={user.avatar} alt={user.name} />
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <span className="font-medium">{user.name}</span>
                            </div>
                            <div className="hidden sm:flex items-center">{user.quizzesCompleted}</div>
                          </div>
                          <div className="font-bold">{user.score}%</div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="history">
                    <div className="flex items-center justify-center h-60">
                      <div className="text-center text-muted-foreground">
                        <p>Select a different category to see rankings</p>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="geography">
                    <div className="flex items-center justify-center h-60">
                      <div className="text-center text-muted-foreground">
                        <p>Select a different category to see rankings</p>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="entertainment">
                    <div className="flex items-center justify-center h-60">
                      <div className="text-center text-muted-foreground">
                        <p>Select a different category to see rankings</p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Sample data
const leaderboardData = [
  {
    id: "1",
    name: "Alex Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 145,
    averageScore: 92,
    points: 12450,
  },
  {
    id: "2",
    name: "Samantha Lee",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 132,
    averageScore: 89,
    points: 11780,
  },
  {
    id: "3",
    name: "Michael Chen",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 128,
    averageScore: 91,
    points: 11650,
  },
  {
    id: "4",
    name: "Emily Wilson",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 115,
    averageScore: 88,
    points: 10120,
  },
  {
    id: "5",
    name: "David Kim",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 110,
    averageScore: 85,
    points: 9350,
  },
  {
    id: "6",
    name: "Jessica Martinez",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 105,
    averageScore: 87,
    points: 9130,
  },
  {
    id: "7",
    name: "Ryan Taylor",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 98,
    averageScore: 84,
    points: 8230,
  },
  {
    id: "8",
    name: "Olivia Brown",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 92,
    averageScore: 86,
    points: 7910,
  },
]

const scienceCategoryData = [
  {
    id: "2",
    name: "Samantha Lee",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 45,
    score: 94,
  },
  {
    id: "1",
    name: "Alex Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 38,
    score: 92,
  },
  {
    id: "5",
    name: "David Kim",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 42,
    score: 90,
  },
  {
    id: "3",
    name: "Michael Chen",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 36,
    score: 89,
  },
  {
    id: "4",
    name: "Emily Wilson",
    avatar: "/placeholder.svg?height=32&width=32",
    quizzesCompleted: 30,
    score: 85,
  },
]

