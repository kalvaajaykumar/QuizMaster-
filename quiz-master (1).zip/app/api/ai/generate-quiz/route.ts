import { NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: Request) {
  try {
    const { topic, description, category, difficulty, questionCount } = await req.json()

    // Generate quiz questions using OpenAI
    const prompt = `
      Create a quiz about "${topic}" with ${questionCount} multiple-choice questions.
      Difficulty level: ${difficulty}
      Category: ${category}
      ${description ? `Additional details: ${description}` : ""}
      
      Format the response as a JSON object with the following structure:
      {
        "title": "Quiz title",
        "description": "Quiz description",
        "questions": [
          {
            "question": "Question text",
            "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
            "correctAnswer": "Correct option (exact text)",
            "hint": "Optional hint"
          }
        ]
      }
    `

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
      temperature: 0.7,
      maxTokens: 2000,
    })

    // Parse the generated quiz
    const generatedQuiz = JSON.parse(text)

    // In a real app, save the quiz to the database
    // const { db } = await connectToDatabase()
    // const result = await db.collection("quizzes").insertOne({
    //   title: generatedQuiz.title,
    //   description: generatedQuiz.description,
    //   category,
    //   difficulty,
    //   questions: generatedQuiz.questions,
    //   createdBy: "user_id", // This would come from the authenticated user
    //   createdAt: new Date(),
    //   isAIGenerated: true
    // })

    // For demo purposes, we'll return a mock quiz ID
    return NextResponse.json({
      success: true,
      quizId: "ai-generated-123",
      quiz: generatedQuiz,
    })
  } catch (error) {
    console.error("Error generating quiz:", error)
    return NextResponse.json({ error: "Failed to generate quiz" }, { status: 500 })
  }
}

