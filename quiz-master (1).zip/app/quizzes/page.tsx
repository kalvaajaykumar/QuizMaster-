import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"

export default function QuizzesPage() {
  return (
    <div className="container py-10">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold">Browse Quizzes</h1>
          <p className="text-muted-foreground">
            Discover quizzes created by our community or search for specific topics
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col gap-4 md:flex-row md:items-end">
          <div className="flex-1 space-y-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search quizzes..." className="w-full pl-8" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 md:flex">
            <Select defaultValue="all">
              <SelectTrigger className="w-full md:w-[150px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="science">Science</SelectItem>
                <SelectItem value="history">History</SelectItem>
                <SelectItem value="geography">Geography</SelectItem>
                <SelectItem value="entertainment">Entertainment</SelectItem>
                <SelectItem value="sports">Sports</SelectItem>
                <SelectItem value="technology">Technology</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="popular">
              <SelectTrigger className="w-full md:w-[150px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="recent">Recently Added</SelectItem>
                <SelectItem value="difficulty-asc">Easiest First</SelectItem>
                <SelectItem value="difficulty-desc">Hardest First</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3 md:w-auto md:grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="popular">Popular</TabsTrigger>
            <TabsTrigger value="new">New</TabsTrigger>
            <TabsTrigger value="recommended" className="hidden md:inline-flex">
              Recommended
            </TabsTrigger>
          </TabsList>
          <TabsContent value="all" className="mt-6">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {quizzes.map((quiz) => (
                <QuizCard key={quiz.id} quiz={quiz} />
              ))}
            </div>
          </TabsContent>
          <TabsContent value="popular" className="mt-6">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {quizzes
                .filter((q) => q.completions > 500)
                .map((quiz) => (
                  <QuizCard key={quiz.id} quiz={quiz} />
                ))}
            </div>
          </TabsContent>
          <TabsContent value="new" className="mt-6">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {quizzes
                .filter((q) => q.isNew)
                .map((quiz) => (
                  <QuizCard key={quiz.id} quiz={quiz} />
                ))}
            </div>
          </TabsContent>
          <TabsContent value="recommended" className="mt-6">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {quizzes
                .filter((q) => q.isRecommended)
                .map((quiz) => (
                  <QuizCard key={quiz.id} quiz={quiz} />
                ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Pagination */}
        <div className="flex justify-center mt-8">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" disabled>
              &lt;
            </Button>
            <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">
              1
            </Button>
            <Button variant="outline" size="sm">
              2
            </Button>
            <Button variant="outline" size="sm">
              3
            </Button>
            <Button variant="outline" size="icon">
              &gt;
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function QuizCard({ quiz }: { quiz: Quiz }) {
  return (
    <Card className="h-full overflow-hidden transition-all hover:shadow-lg">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{quiz.title}</CardTitle>
            <CardDescription>{quiz.category}</CardDescription>
          </div>
          {quiz.isNew && (
            <span className="px-2 py-1 text-xs font-medium rounded-full bg-primary/10 text-primary">New</span>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm">{quiz.description}</p>
        <div className="flex items-center gap-2 mt-4">
          <div className="flex items-center text-sm text-muted-foreground">
            <span className="font-medium">{quiz.difficulty}</span>
          </div>
          <div className="text-sm text-muted-foreground">•</div>
          <div className="text-sm text-muted-foreground">{quiz.questionCount} questions</div>
          <div className="text-sm text-muted-foreground">•</div>
          <div className="text-sm text-muted-foreground">{quiz.timeEstimate}</div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div className="text-sm text-muted-foreground">{quiz.completions} completions</div>
        <Link href={`/quizzes/${quiz.id}`}>
          <Button size="sm">Take Quiz</Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

// Types
interface Quiz {
  id: string
  title: string
  category: string
  description: string
  difficulty: "Easy" | "Medium" | "Hard"
  questionCount: number
  timeEstimate: string
  completions: number
  isNew?: boolean
  isRecommended?: boolean
}

// Sample data
const quizzes: Quiz[] = [
  {
    id: "1",
    title: "World Geography Challenge",
    category: "Geography",
    description: "Test your knowledge of world capitals, landmarks, and geographical features.",
    difficulty: "Medium",
    questionCount: 15,
    timeEstimate: "10 min",
    completions: 1243,
    isRecommended: true,
  },
  {
    id: "2",
    title: "Science Quiz: The Human Body",
    category: "Science",
    description: "Explore the amazing systems and functions of the human body.",
    difficulty: "Medium",
    questionCount: 20,
    timeEstimate: "15 min",
    completions: 987,
    isRecommended: true,
  },
  {
    id: "3",
    title: "History: Ancient Civilizations",
    category: "History",
    description: "Journey through the great ancient civilizations and their contributions.",
    difficulty: "Hard",
    questionCount: 25,
    timeEstimate: "20 min",
    completions: 756,
  },
  {
    id: "4",
    title: "Pop Culture Trivia 2024",
    category: "Entertainment",
    description: "Stay current with this quiz on the latest trends in movies, music, and more.",
    difficulty: "Easy",
    questionCount: 15,
    timeEstimate: "10 min",
    completions: 1892,
    isNew: true,
    isRecommended: true,
  },
  {
    id: "5",
    title: "Coding Concepts for Beginners",
    category: "Technology",
    description: "Learn the basics of programming with this interactive quiz.",
    difficulty: "Easy",
    questionCount: 10,
    timeEstimate: "8 min",
    completions: 543,
  },
  {
    id: "6",
    title: "Math Brain Teasers",
    category: "Mathematics",
    description: "Challenge your problem-solving skills with these math puzzles.",
    difficulty: "Hard",
    questionCount: 12,
    timeEstimate: "15 min",
    completions: 421,
  },
  {
    id: "7",
    title: "Famous Artists and Their Works",
    category: "Art",
    description: "Test your knowledge of famous artists and their masterpieces throughout history.",
    difficulty: "Medium",
    questionCount: 15,
    timeEstimate: "12 min",
    completions: 328,
    isNew: true,
  },
  {
    id: "8",
    title: "World Cuisines",
    category: "Food",
    description: "Explore traditional dishes and cooking techniques from around the world.",
    difficulty: "Easy",
    questionCount: 10,
    timeEstimate: "8 min",
    completions: 612,
    isNew: true,
  },
  {
    id: "9",
    title: "Space Exploration",
    category: "Science",
    description: "Journey through the history and future of human space exploration.",
    difficulty: "Medium",
    questionCount: 18,
    timeEstimate: "15 min",
    completions: 489,
  },
]

