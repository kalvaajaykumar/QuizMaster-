"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { AlertTriangle, Check, Loader2 } from "lucide-react"
import ImageUpload from "@/components/image-upload"

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("general")
  const [isUpdating, setIsUpdating] = useState(false)
  const [updateSuccess, setUpdateSuccess] = useState(false)
  const [updateError, setUpdateError] = useState<string | null>(null)

  // User profile state
  const [name, setName] = useState("Demo User")
  const [email, setEmail] = useState("user@example.com")
  const [bio, setBio] = useState("Quiz enthusiast and lifelong learner")
  const [avatarUrl, setAvatarUrl] = useState("/placeholder.svg?height=100&width=100")

  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [quizCompletions, setQuizCompletions] = useState(true)
  const [newQuizzes, setNewQuizzes] = useState(true)
  const [leaderboardUpdates, setLeaderboardUpdates] = useState(false)

  // Security settings
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsUpdating(true)
    setUpdateSuccess(false)
    setUpdateError(null)

    try {
      // In a real app, this would call the API to update the profile
      // await fetch('/api/profile', {
      //   method: 'PUT',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ name, email, bio, avatarUrl })
      // })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setUpdateSuccess(true)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setUpdateSuccess(false)
      }, 3000)
    } catch (error) {
      console.error("Error updating profile:", error)
      setUpdateError("Failed to update profile. Please try again.")
    } finally {
      setIsUpdating(false)
    }
  }

  const handleUpdateNotifications = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsUpdating(true)
    setUpdateSuccess(false)
    setUpdateError(null)

    try {
      // In a real app, this would call the API to update notification settings
      // await fetch('/api/profile/notifications', {
      //   method: 'PUT',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({
      //     emailNotifications,
      //     quizCompletions,
      //     newQuizzes,
      //     leaderboardUpdates
      //   })
      // })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setUpdateSuccess(true)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setUpdateSuccess(false)
      }, 3000)
    } catch (error) {
      console.error("Error updating notification settings:", error)
      setUpdateError("Failed to update notification settings. Please try again.")
    } finally {
      setIsUpdating(false)
    }
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsUpdating(true)
    setUpdateSuccess(false)
    setUpdateError(null)

    if (newPassword !== confirmPassword) {
      setUpdateError("New passwords do not match")
      setIsUpdating(false)
      return
    }

    if (newPassword.length < 8) {
      setUpdateError("Password must be at least 8 characters long")
      setIsUpdating(false)
      return
    }

    try {
      // In a real app, this would call the API to change the password
      // await fetch('/api/profile/password', {
      //   method: 'PUT',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ currentPassword, newPassword })
      // })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setUpdateSuccess(true)

      // Reset form and success message
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")

      setTimeout(() => {
        setUpdateSuccess(false)
      }, 3000)
    } catch (error) {
      console.error("Error changing password:", error)
      setUpdateError("Failed to change password. Please check your current password and try again.")
    } finally {
      setIsUpdating(false)
    }
  }

  return (
    <div className="container py-10 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Profile Settings</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-6">
          <Card>
            <form onSubmit={handleUpdateProfile}>
              <CardHeader>
                <CardTitle>General Information</CardTitle>
                <CardDescription>Update your profile information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center sm:flex-row sm:items-start gap-6">
                  <div className="flex flex-col items-center gap-2">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={avatarUrl} alt={name} />
                      <AvatarFallback>{name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <ImageUpload onImageUploaded={setAvatarUrl} defaultImage={avatarUrl} className="w-full" />
                  </div>

                  <div className="space-y-4 flex-1">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Input id="bio" value={bio} onChange={(e) => setBio(e.target.value)} />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-4">
                {updateSuccess && (
                  <div className="flex items-center text-green-600 dark:text-green-400 text-sm w-full">
                    <Check className="mr-1 h-4 w-4" />
                    Profile updated successfully
                  </div>
                )}

                {updateError && (
                  <div className="flex items-center text-destructive text-sm w-full">
                    <AlertTriangle className="mr-1 h-4 w-4" />
                    {updateError}
                  </div>
                )}

                <Button type="submit" className="ml-auto" disabled={isUpdating}>
                  {isUpdating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="mt-6">
          <Card>
            <form onSubmit={handleUpdateNotifications}>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>Manage how you receive notifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="email-notifications" className="text-base">
                        Email Notifications
                      </Label>
                      <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                    </div>
                    <Switch
                      id="email-notifications"
                      checked={emailNotifications}
                      onCheckedChange={setEmailNotifications}
                    />
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Notification Types</h3>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="quiz-completions" className="text-sm">
                          Quiz Completions
                        </Label>
                        <p className="text-xs text-muted-foreground">Notifications when someone completes your quiz</p>
                      </div>
                      <Switch
                        id="quiz-completions"
                        checked={quizCompletions}
                        onCheckedChange={setQuizCompletions}
                        disabled={!emailNotifications}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="new-quizzes" className="text-sm">
                          New Quizzes
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Notifications about new quizzes in your favorite categories
                        </p>
                      </div>
                      <Switch
                        id="new-quizzes"
                        checked={newQuizzes}
                        onCheckedChange={setNewQuizzes}
                        disabled={!emailNotifications}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="leaderboard-updates" className="text-sm">
                          Leaderboard Updates
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Notifications about changes in your leaderboard position
                        </p>
                      </div>
                      <Switch
                        id="leaderboard-updates"
                        checked={leaderboardUpdates}
                        onCheckedChange={setLeaderboardUpdates}
                        disabled={!emailNotifications}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-4">
                {updateSuccess && (
                  <div className="flex items-center text-green-600 dark:text-green-400 text-sm w-full">
                    <Check className="mr-1 h-4 w-4" />
                    Notification settings updated successfully
                  </div>
                )}

                {updateError && (
                  <div className="flex items-center text-destructive text-sm w-full">
                    <AlertTriangle className="mr-1 h-4 w-4" />
                    {updateError}
                  </div>
                )}

                <Button type="submit" className="ml-auto" disabled={isUpdating}>
                  {isUpdating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="mt-6">
          <Card>
            <form onSubmit={handleChangePassword}>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>Update your password and security preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-sm font-medium">Change Password</h3>

                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input
                      id="current-password"
                      type="password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input
                      id="new-password"
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-4">
                {updateSuccess && (
                  <div className="flex items-center text-green-600 dark:text-green-400 text-sm w-full">
                    <Check className="mr-1 h-4 w-4" />
                    Password changed successfully
                  </div>
                )}

                {updateError && (
                  <div className="flex items-center text-destructive text-sm w-full">
                    <AlertTriangle className="mr-1 h-4 w-4" />
                    {updateError}
                  </div>
                )}

                <Button
                  type="submit"
                  className="ml-auto"
                  disabled={isUpdating || !currentPassword || !newPassword || !confirmPassword}
                >
                  {isUpdating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Change Password"
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

