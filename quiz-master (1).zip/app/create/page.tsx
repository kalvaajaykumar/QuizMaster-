"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, Trash2, HelpCircle, Save, ArrowRight } from "lucide-react"
import ImageUpload from "@/components/image-upload"

export default function CreateQuizPage() {
  const [quizTitle, setQuizTitle] = useState("")
  const [quizDescription, setQuizDescription] = useState("")
  const [quizCategory, setQuizCategory] = useState("")
  const [quizDifficulty, setQuizDifficulty] = useState("")
  const [timeLimit, setTimeLimit] = useState("10")
  const [coverImage, setCoverImage] = useState("")
  const [questions, setQuestions] = useState<Question[]>([
    {
      question: "",
      options: ["", "", "", ""],
      correctAnswer: 0,
      hint: "",
      image: "",
    },
  ])
  const [currentStep, setCurrentStep] = useState(0)
  const [showSuccessDialog, setShowSuccessDialog] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const addQuestion = () => {
    setQuestions([
      ...questions,
      {
        question: "",
        options: ["", "", "", ""],
        correctAnswer: 0,
        hint: "",
        image: "",
      },
    ])
  }

  const removeQuestion = (index: number) => {
    if (questions.length > 1) {
      const newQuestions = [...questions]
      newQuestions.splice(index, 1)
      setQuestions(newQuestions)
    }
  }

  const updateQuestion = (index: number, field: keyof Question, value: string | number | string[]) => {
    const newQuestions = [...questions]
    if (field === "options" && typeof value === "string") {
      // Handle updating a single option
      const optionIndex = Number.parseInt(value.split("-")[0])
      const optionValue = value.split("-")[1]
      newQuestions[index].options[optionIndex] = optionValue
    } else {
      // @ts-ignore - We know this is safe
      newQuestions[index][field] = value
    }
    setQuestions(newQuestions)
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    setError(null)

    try {
      // In a real app, this would send data to the backend
      const response = await fetch("/api/quizzes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: quizTitle,
          description: quizDescription,
          category: quizCategory,
          difficulty: quizDifficulty,
          timeLimit: Number.parseInt(timeLimit),
          coverImage,
          questions: questions.map((q) => ({
            ...q,
            // Ensure correctAnswer is the actual answer text, not just the index
            correctAnswer: q.options[q.correctAnswer],
          })),
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Failed to create quiz")
      }

      setShowSuccessDialog(true)
    } catch (error) {
      console.error("Error creating quiz:", error)
      setError(error instanceof Error ? error.message : "An unexpected error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  const isStepOneValid = quizTitle && quizDescription && quizCategory && quizDifficulty && timeLimit

  const isStepTwoValid = questions.every(
    (q) => q.question.trim() !== "" && q.options.every((opt) => opt.trim() !== "") && q.correctAnswer !== undefined,
  )

  return (
    <div className="container py-10 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Create a New Quiz</h1>
        <p className="text-muted-foreground">
          Design your own quiz with custom questions and share it with the community
        </p>
      </div>

      <Tabs
        value={currentStep === 0 ? "details" : "questions"}
        onValueChange={(value) => setCurrentStep(value === "details" ? 0 : 1)}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="details">Quiz Details</TabsTrigger>
          <TabsTrigger value="questions" disabled={!isStepOneValid}>
            Questions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
              <CardDescription>Provide general information about your quiz</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Quiz Title</Label>
                <Input
                  id="title"
                  placeholder="Enter a title for your quiz"
                  value={quizTitle}
                  onChange={(e) => setQuizTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what your quiz is about"
                  rows={3}
                  value={quizDescription}
                  onChange={(e) => setQuizDescription(e.target.value)}
                />
              </div>

              <ImageUpload onImageUploaded={(url) => setCoverImage(url)} defaultImage={coverImage} className="mb-4" />

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={quizCategory} onValueChange={setQuizCategory}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="science">Science</SelectItem>
                      <SelectItem value="history">History</SelectItem>
                      <SelectItem value="geography">Geography</SelectItem>
                      <SelectItem value="entertainment">Entertainment</SelectItem>
                      <SelectItem value="sports">Sports</SelectItem>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="art">Art</SelectItem>
                      <SelectItem value="food">Food</SelectItem>
                      <SelectItem value="mathematics">Mathematics</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select value={quizDifficulty} onValueChange={setQuizDifficulty}>
                    <SelectTrigger id="difficulty">
                      <SelectValue placeholder="Select difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="hard">Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="time-limit">Time Limit (minutes)</Label>
                <Input
                  id="time-limit"
                  type="number"
                  min="1"
                  max="60"
                  value={timeLimit}
                  onChange={(e) => setTimeLimit(e.target.value)}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto" onClick={() => setCurrentStep(1)} disabled={!isStepOneValid}>
                Next: Add Questions
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="questions" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Quiz Questions</CardTitle>
              <CardDescription>Add multiple-choice questions to your quiz</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {questions.map((question, questionIndex) => (
                <div key={questionIndex} className="space-y-4 p-4 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Question {questionIndex + 1}</h3>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeQuestion(questionIndex)}
                      disabled={questions.length === 1}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Remove question</span>
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`question-${questionIndex}`}>Question</Label>
                    <Input
                      id={`question-${questionIndex}`}
                      placeholder="Enter your question"
                      value={question.question}
                      onChange={(e) => updateQuestion(questionIndex, "question", e.target.value)}
                    />
                  </div>

                  <ImageUpload
                    onImageUploaded={(url) => updateQuestion(questionIndex, "image", url)}
                    defaultImage={question.image}
                    className="mb-4"
                  />

                  <div className="space-y-4">
                    <Label>Answer Options</Label>
                    {question.options.map((option, optionIndex) => (
                      <div key={optionIndex} className="flex items-center gap-2">
                        <Input
                          placeholder={`Option ${optionIndex + 1}`}
                          value={option}
                          onChange={(e) => updateQuestion(questionIndex, "options", `${optionIndex}-${e.target.value}`)}
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          className={question.correctAnswer === optionIndex ? "bg-green-100 dark:bg-green-900" : ""}
                          onClick={() => updateQuestion(questionIndex, "correctAnswer", optionIndex)}
                        >
                          {question.correctAnswer === optionIndex ? "Correct" : "Mark Correct"}
                        </Button>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-1">
                      <Label htmlFor={`hint-${questionIndex}`}>Hint (Optional)</Label>
                      <HelpCircle className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <Input
                      id={`hint-${questionIndex}`}
                      placeholder="Add a hint for this question"
                      value={question.hint}
                      onChange={(e) => updateQuestion(questionIndex, "hint", e.target.value)}
                    />
                  </div>
                </div>
              ))}

              <Button variant="outline" className="w-full" onClick={addQuestion}>
                <Plus className="mr-2 h-4 w-4" />
                Add Another Question
              </Button>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              {error && <p className="text-sm font-medium text-destructive w-full text-center">{error}</p>}
              <div className="flex justify-between w-full">
                <Button variant="outline" onClick={() => setCurrentStep(0)}>
                  Back to Details
                </Button>
                <Button onClick={handleSubmit} disabled={!isStepTwoValid || isSubmitting}>
                  {isSubmitting ? (
                    <>Saving Quiz...</>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Quiz
                    </>
                  )}
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <AlertDialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Quiz Created Successfully!</AlertDialogTitle>
            <AlertDialogDescription>
              Your quiz has been created and is now available for others to take. You can view and edit your quiz from
              your dashboard.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction asChild>
              <Button asChild>
                <a href="/dashboard">Go to Dashboard</a>
              </Button>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// Types
interface Question {
  question: string
  options: string[]
  correctAnswer: number
  hint: string
  image: string
}

