import { NextResponse } from "next/server"

export async function GET(req: Request) {
  try {
    const url = new URL(req.url)
    const category = url.searchParams.get("category")
    const difficulty = url.searchParams.get("difficulty")
    const search = url.searchParams.get("search")
    const sort = url.searchParams.get("sort") || "popular"
    const page = Number.parseInt(url.searchParams.get("page") || "1")
    const limit = Number.parseInt(url.searchParams.get("limit") || "10")

    // In a real app, fetch quizzes from the database
    // const { db } = await connectToDatabase()

    // Build the query
    // let query: any = {}
    // if (category && category !== "all") query.category = category
    // if (difficulty && difficulty !== "all") query.difficulty = difficulty
    // if (search) query.title = { $regex: search, $options: "i" }

    // Determine the sort order
    // let sortOptions: any = {}
    // if (sort === "popular") sortOptions.completions = -1
    // else if (sort === "recent") sortOptions.createdAt = -1
    // else if (sort === "difficulty-asc") sortOptions.difficulty = 1
    // else if (sort === "difficulty-desc") sortOptions.difficulty = -1

    // const quizzes = await db.collection("quizzes")
    //   .find(query)
    //   .sort(sortOptions)
    //   .skip((page - 1) * limit)
    //   .limit(limit)
    //   .toArray()

    // const total = await db.collection("quizzes").countDocuments(query)

    // For demo purposes, return mock data
    const quizzes = mockQuizzes
      .filter((q) => {
        if (category && category !== "all" && q.category.toLowerCase() !== category.toLowerCase()) return false
        if (difficulty && difficulty !== "all" && q.difficulty.toLowerCase() !== difficulty.toLowerCase()) return false
        if (search && !q.title.toLowerCase().includes(search.toLowerCase())) return false
        return true
      })
      .sort((a, b) => {
        if (sort === "popular") return b.completions - a.completions
        if (sort === "recent") return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        if (sort === "difficulty-asc") {
          const difficultyOrder = { Easy: 1, Medium: 2, Hard: 3 }
          return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty]
        }
        if (sort === "difficulty-desc") {
          const difficultyOrder = { Easy: 1, Medium: 2, Hard: 3 }
          return difficultyOrder[b.difficulty] - difficultyOrder[a.difficulty]
        }
        return 0
      })
      .slice((page - 1) * limit, page * limit)

    const total = mockQuizzes.length

    return NextResponse.json({
      quizzes,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching quizzes:", error)
    return NextResponse.json({ error: "Failed to fetch quizzes" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const quizData = await req.json()

    // Validate the quiz data
    if (!quizData.title || !quizData.category || !quizData.questions || quizData.questions.length === 0) {
      return NextResponse.json({ error: "Invalid quiz data" }, { status: 400 })
    }

    // In a real app, save the quiz to the database
    // const { db } = await connectToDatabase()
    // const result = await db.collection("quizzes").insertOne({
    //   ...quizData,
    //   createdBy: "user_id", // This would come from the authenticated user
    //   createdAt: new Date(),
    //   completions: 0
    // })

    // For demo purposes, return a mock quiz ID
    return NextResponse.json({
      success: true,
      quizId: "new-quiz-123",
    })
  } catch (error) {
    console.error("Error creating quiz:", error)
    return NextResponse.json({ error: "Failed to create quiz" }, { status: 500 })
  }
}

// Mock data for demo purposes
const mockQuizzes = [
  {
    id: "1",
    title: "World Geography Challenge",
    category: "Geography",
    description: "Test your knowledge of world capitals, landmarks, and geographical features.",
    difficulty: "Medium",
    questionCount: 15,
    timeEstimate: "10 min",
    completions: 1243,
    createdAt: "2024-02-15T12:00:00Z",
    isRecommended: true,
  },
  {
    id: "2",
    title: "Science Quiz: The Human Body",
    category: "Science",
    description: "Explore the amazing systems and functions of the human body.",
    difficulty: "Medium",
    questionCount: 20,
    timeEstimate: "15 min",
    completions: 987,
    createdAt: "2024-02-20T12:00:00Z",
    isRecommended: true,
  },
  {
    id: "3",
    title: "History: Ancient Civilizations",
    category: "History",
    description: "Journey through the great ancient civilizations and their contributions.",
    difficulty: "Hard",
    questionCount: 25,
    timeEstimate: "20 min",
    completions: 756,
    createdAt: "2024-02-25T12:00:00Z",
  },
  {
    id: "4",
    title: "Pop Culture Trivia 2024",
    category: "Entertainment",
    description: "Stay current with this quiz on the latest trends in movies, music, and more.",
    difficulty: "Easy",
    questionCount: 15,
    timeEstimate: "10 min",
    completions: 1892,
    createdAt: "2024-03-01T12:00:00Z",
    isNew: true,
    isRecommended: true,
  },
  {
    id: "5",
    title: "Coding Concepts for Beginners",
    category: "Technology",
    description: "Learn the basics of programming with this interactive quiz.",
    difficulty: "Easy",
    questionCount: 10,
    timeEstimate: "8 min",
    completions: 543,
    createdAt: "2024-03-05T12:00:00Z",
  },
  {
    id: "6",
    title: "Math Brain Teasers",
    category: "Mathematics",
    description: "Challenge your problem-solving skills with these math puzzles.",
    difficulty: "Hard",
    questionCount: 12,
    timeEstimate: "15 min",
    completions: 421,
    createdAt: "2024-03-07T12:00:00Z",
  },
]

