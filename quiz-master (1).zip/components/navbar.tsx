"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Moon, Sun, User, Sparkles } from "lucide-react"
import { useTheme } from "next-themes"

export default function Navbar() {
  const { setTheme } = useTheme()
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[240px] sm:w-[300px]">
              <nav className="flex flex-col gap-4 mt-8">
                <Link href="/" className="text-lg font-semibold">
                  Home
                </Link>
                <Link href="/quizzes" className="text-lg font-semibold">
                  Quizzes
                </Link>
                <Link href="/create" className="text-lg font-semibold">
                  Create Quiz
                </Link>
                <Link href="/ai-quiz-generator" className="text-lg font-semibold flex items-center">
                  <Sparkles className="mr-2 h-4 w-4 text-primary" />
                  AI Quiz Generator
                </Link>
                <Link href="/leaderboard" className="text-lg font-semibold">
                  Leaderboard
                </Link>
                {!isLoggedIn ? (
                  <>
                    <Link href="/auth/login" className="text-lg font-semibold">
                      Login
                    </Link>
                    <Link href="/auth/register" className="text-lg font-semibold">
                      Register
                    </Link>
                  </>
                ) : (
                  <>
                    <Link href="/dashboard" className="text-lg font-semibold">
                      Dashboard
                    </Link>
                    <Link href="/profile" className="text-lg font-semibold">
                      Profile
                    </Link>
                    <Button
                      variant="ghost"
                      className="justify-start p-0 text-lg font-semibold"
                      onClick={() => setIsLoggedIn(false)}
                    >
                      Logout
                    </Button>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl font-bold">Quiz Master</span>
          </Link>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/quizzes" className="text-sm font-medium">
            Quizzes
          </Link>
          <Link href="/create" className="text-sm font-medium">
            Create Quiz
          </Link>
          <Link href="/ai-quiz-generator" className="text-sm font-medium flex items-center">
            <Sparkles className="mr-1 h-3 w-3 text-primary" />
            AI Generator
          </Link>
          <Link href="/leaderboard" className="text-sm font-medium">
            Leaderboard
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                <span className="sr-only">Toggle theme</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setTheme("light")}>Light</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("dark")}>Dark</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("system")}>System</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          {!isLoggedIn ? (
            <div className="flex items-center gap-2">
              <Link href="/auth/login">
                <Button variant="ghost" size="sm">
                  Login
                </Button>
              </Link>
              <Link href="/auth/register">
                <Button size="sm">Register</Button>
              </Link>
            </div>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                  <span className="sr-only">User menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/dashboard">Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setIsLoggedIn(false)}>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </header>
  )
}

