import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Trophy, Users, BookOpen, Brain, Sparkles } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-background to-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">Quiz Master</h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Create, share, and take quizzes on any topic. Test your knowledge and challenge your friends.
              </p>
            </div>
            <div className="space-x-4">
              <Link href="/quizzes">
                <Button size="lg">Browse Quizzes</Button>
              </Link>
              <Link href="/auth/login">
                <Button variant="outline" size="lg">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* AI Feature Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary/5">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
              New Feature
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl flex items-center justify-center">
                <Sparkles className="mr-2 h-8 w-8 text-primary" />
                AI-Powered Quiz Generation
              </h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Let our advanced AI create custom quizzes for you on any topic in seconds
              </p>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card className="flex flex-col items-center text-center">
                <CardHeader>
                  <CardTitle>Instant Creation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Generate complete quizzes with just a few clicks - no manual question writing needed
                  </p>
                </CardContent>
              </Card>
              <Card className="flex flex-col items-center text-center">
                <CardHeader>
                  <CardTitle>Custom Difficulty</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Tailor the challenge level from beginner to expert for any subject
                  </p>
                </CardContent>
              </Card>
              <Card className="flex flex-col items-center text-center md:col-span-2 lg:col-span-1">
                <CardHeader>
                  <CardTitle>Endless Topics</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Create quizzes on virtually any subject with accurate, well-researched questions
                  </p>
                </CardContent>
              </Card>
            </div>
            <Link href="/ai-quiz-generator">
              <Button size="lg" className="mt-4">
                <Sparkles className="mr-2 h-4 w-4" />
                Try AI Quiz Generator
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 xl:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <BookOpen className="h-6 w-6 text-primary mb-2" />
                <CardTitle>Create Quizzes</CardTitle>
                <CardDescription>Build custom quizzes on any topic with multiple question types</CardDescription>
              </CardHeader>
              <CardContent className="text-sm">
                Create engaging quizzes with multiple-choice, true/false, and open-ended questions.
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Brain className="h-6 w-6 text-primary mb-2" />
                <CardTitle>Test Knowledge</CardTitle>
                <CardDescription>Challenge yourself with quizzes from various categories</CardDescription>
              </CardHeader>
              <CardContent className="text-sm">
                Explore quizzes in categories like science, history, pop culture, and more.
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Users className="h-6 w-6 text-primary mb-2" />
                <CardTitle>Compete</CardTitle>
                <CardDescription>Challenge friends and see who scores the highest</CardDescription>
              </CardHeader>
              <CardContent className="text-sm">
                Share quizzes with friends and compare scores on the leaderboard.
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Trophy className="h-6 w-6 text-primary mb-2" />
                <CardTitle>Track Progress</CardTitle>
                <CardDescription>Monitor your performance and improvement over time</CardDescription>
              </CardHeader>
              <CardContent className="text-sm">
                View detailed statistics and track your progress with personalized insights.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Popular Quizzes Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Popular Quizzes</h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Discover trending quizzes created by our community
              </p>
            </div>
          </div>
          <div className="grid gap-6 mt-8 md:grid-cols-2 lg:grid-cols-3">
            {popularQuizzes.map((quiz) => (
              <Link href={`/quizzes/${quiz.id}`} key={quiz.id}>
                <Card className="h-full overflow-hidden transition-all hover:shadow-lg">
                  <CardHeader className="pb-2">
                    <CardTitle>{quiz.title}</CardTitle>
                    <CardDescription>{quiz.category}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{quiz.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <p className="text-sm text-muted-foreground">{quiz.questionCount} questions</p>
                    <p className="text-sm text-muted-foreground">{quiz.completions} completions</p>
                  </CardFooter>
                </Card>
              </Link>
            ))}
          </div>
          <div className="flex justify-center mt-8">
            <Link href="/quizzes">
              <Button variant="outline">View All Quizzes</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

// Sample data for popular quizzes
const popularQuizzes = [
  {
    id: "1",
    title: "World Geography Challenge",
    category: "Geography",
    description: "Test your knowledge of world capitals, landmarks, and geographical features.",
    questionCount: 15,
    completions: 1243,
  },
  {
    id: "2",
    title: "Science Quiz: The Human Body",
    category: "Science",
    description: "Explore the amazing systems and functions of the human body.",
    questionCount: 20,
    completions: 987,
  },
  {
    id: "3",
    title: "History: Ancient Civilizations",
    category: "History",
    description: "Journey through the great ancient civilizations and their contributions.",
    questionCount: 25,
    completions: 756,
  },
  {
    id: "4",
    title: "Pop Culture Trivia 2024",
    category: "Entertainment",
    description: "Stay current with this quiz on the latest trends in movies, music, and more.",
    questionCount: 15,
    completions: 1892,
  },
  {
    id: "5",
    title: "Coding Concepts for Beginners",
    category: "Technology",
    description: "Learn the basics of programming with this interactive quiz.",
    questionCount: 10,
    completions: 543,
  },
  {
    id: "6",
    title: "Math Brain Teasers",
    category: "Mathematics",
    description: "Challenge your problem-solving skills with these math puzzles.",
    questionCount: 12,
    completions: 421,
  },
]

