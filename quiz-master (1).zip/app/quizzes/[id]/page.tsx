"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Clock, HelpCircle, AlertTriangle } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

export default function QuizPage({ params }: { params: { id: string } }) {
  const [quiz, setQuiz] = useState<Quiz | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([])
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [score, setScore] = useState(0)
  const [timeRemaining, setTimeRemaining] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    const fetchQuiz = async () => {
      try {
        // In a real app, this would fetch from the API
        // const response = await fetch(`/api/quizzes/${params.id}`)
        // if (!response.ok) {
        //   throw new Error('Failed to fetch quiz')
        // }
        // const data = await response.json()
        // setQuiz(data)

        // For demo purposes, use the sample quiz data
        setQuiz(sampleQuiz)
        setTimeRemaining(sampleQuiz.timeLimit)
        setSelectedAnswers(Array(sampleQuiz.questions.length).fill(""))
      } catch (error) {
        console.error("Error fetching quiz:", error)
        setError("Failed to load quiz. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchQuiz()
  }, [params.id])

  useEffect(() => {
    if (!quiz || quizCompleted) return

    // Set up timer
    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          handleTimeUp()
          return 0
        }
        return prev - 1
      })
    }, 60000) // Update every minute

    return () => clearInterval(timer)
  }, [quiz, quizCompleted])

  const handleTimeUp = () => {
    // Auto-submit the quiz when time is up
    handleFinishQuiz()
  }

  const handleAnswerSelect = (value: string) => {
    if (isSubmitting) return

    const newSelectedAnswers = [...selectedAnswers]
    newSelectedAnswers[currentQuestionIndex] = value
    setSelectedAnswers(newSelectedAnswers)
  }

  const handleNextQuestion = () => {
    if (isSubmitting) return

    if (currentQuestionIndex < (quiz?.questions.length || 0) - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    } else {
      handleFinishQuiz()
    }
  }

  const handlePreviousQuestion = () => {
    if (isSubmitting || currentQuestionIndex === 0) return
    setCurrentQuestionIndex(currentQuestionIndex - 1)
  }

  const handleFinishQuiz = async () => {
    if (!quiz || isSubmitting) return

    setIsSubmitting(true)

    try {
      // Calculate score
      let correctAnswers = 0
      quiz.questions.forEach((question, index) => {
        if (selectedAnswers[index] === question.correctAnswer) {
          correctAnswers++
        }
      })

      const finalScore = correctAnswers
      setScore(finalScore)

      // In a real app, submit the results to the API
      // await fetch('/api/quiz-results', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify({
      //     quizId: params.id,
      //     answers: selectedAnswers,
      //     score: finalScore,
      //     timeSpent: quiz.timeLimit - timeRemaining
      //   }),
      // })

      setQuizCompleted(true)
    } catch (error) {
      console.error("Error submitting quiz results:", error)
      setError("Failed to submit quiz results. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleRestartQuiz = () => {
    if (!quiz) return

    setCurrentQuestionIndex(0)
    setSelectedAnswers(Array(quiz.questions.length).fill(""))
    setQuizCompleted(false)
    setScore(0)
    setTimeRemaining(quiz.timeLimit)
    setError(null)
  }

  if (loading) {
    return (
      <div className="container py-10 max-w-4xl">
        <div className="mb-6">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-full max-w-md" />
        </div>

        <Skeleton className="h-4 w-48 mb-4" />
        <Skeleton className="h-2 w-full mb-6" />

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-full max-w-md mb-2" />
            <Skeleton className="h-4 w-full max-w-sm" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Skeleton className="h-10 w-24" />
            <Skeleton className="h-10 w-24" />
          </CardFooter>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container py-10 max-w-4xl">
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center text-destructive">
              <AlertTriangle className="mr-2 h-5 w-5" />
              Error Loading Quiz
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error}</p>
          </CardContent>
          <CardFooter>
            <Link href="/quizzes">
              <Button>Back to Quizzes</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    )
  }

  if (!quiz) {
    return (
      <div className="container py-10 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle>Quiz Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p>The quiz you're looking for could not be found. It may have been removed or is no longer available.</p>
          </CardContent>
          <CardFooter>
            <Link href="/quizzes">
              <Button>Browse Quizzes</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    )
  }

  if (quizCompleted) {
    return (
      <div className="container py-10 max-w-4xl">
        <Card className="w-full">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Quiz Results</CardTitle>
            <CardDescription>
              You scored {score} out of {quiz.questions.length} questions correctly
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex justify-center">
              <div className="w-48 h-48 rounded-full border-8 border-primary flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl font-bold">{Math.round((score / quiz.questions.length) * 100)}%</div>
                  <div className="text-sm text-muted-foreground">Score</div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Performance Summary</h3>
              <div className="grid gap-2">
                <div className="flex justify-between">
                  <span>Correct Answers:</span>
                  <span className="font-medium">{score}</span>
                </div>
                <div className="flex justify-between">
                  <span>Incorrect Answers:</span>
                  <span className="font-medium">{quiz.questions.length - score}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Questions:</span>
                  <span className="font-medium">{quiz.questions.length}</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Feedback</h3>
              <p className="text-muted-foreground">
                {score === quiz.questions.length
                  ? "Perfect score! You've mastered this topic."
                  : score >= quiz.questions.length * 0.7
                    ? "Great job! You have a solid understanding of this topic."
                    : score >= quiz.questions.length * 0.5
                      ? "Good effort! With a bit more study, you'll improve your score."
                      : "Keep practicing! Review the material and try again to improve your score."}
              </p>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={handleRestartQuiz}>Restart Quiz</Button>
            <Link href="/quizzes">
              <Button variant="outline">Browse More Quizzes</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    )
  }

  const currentQuestion = quiz.questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100

  return (
    <div className="container py-10 max-w-4xl">
      <div className="mb-6">
        <Link href="/quizzes" className="flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Quizzes
        </Link>
      </div>

      <div className="mb-6">
        <h1 className="text-2xl font-bold">{quiz.title}</h1>
        <p className="text-muted-foreground">{quiz.description}</p>
      </div>

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <span className="text-sm font-medium">
            Question {currentQuestionIndex + 1} of {quiz.questions.length}
          </span>
        </div>
        <div className="flex items-center text-sm text-muted-foreground">
          <Clock className="mr-1 h-4 w-4" />
          <span>{timeRemaining} minutes remaining</span>
        </div>
      </div>

      <Progress value={progress} className="mb-6" />

      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-xl">{currentQuestion.question}</CardTitle>
          {currentQuestion.hint && (
            <CardDescription className="flex items-center mt-2">
              <HelpCircle className="mr-1 h-4 w-4" />
              Hint: {currentQuestion.hint}
            </CardDescription>
          )}
        </CardHeader>
        <CardContent>
          {currentQuestion.image && (
            <div className="mb-4">
              <img
                src={currentQuestion.image || "/placeholder.svg"}
                alt="Question image"
                className="rounded-md max-h-64 mx-auto"
              />
            </div>
          )}

          <RadioGroup
            value={selectedAnswers[currentQuestionIndex]}
            onValueChange={handleAnswerSelect}
            className="space-y-3"
          >
            {currentQuestion.options.map((option, index) => (
              <div
                key={index}
                className={`flex items-center space-x-2 rounded-lg border p-4 transition-colors ${
                  selectedAnswers[currentQuestionIndex] === option ? "border-primary bg-primary/5" : "hover:bg-muted/50"
                }`}
              >
                <RadioGroupItem value={option} id={`option-${index}`} className="sr-only" />
                <Label
                  htmlFor={`option-${index}`}
                  className="flex flex-1 cursor-pointer items-center justify-between text-base"
                >
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePreviousQuestion}
            disabled={currentQuestionIndex === 0 || isSubmitting}
          >
            Previous
          </Button>
          <Button onClick={handleNextQuestion} disabled={!selectedAnswers[currentQuestionIndex] || isSubmitting}>
            {currentQuestionIndex === quiz.questions.length - 1 ? "Finish Quiz" : "Next Question"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

// Types
interface Question {
  question: string
  options: string[]
  correctAnswer: string
  hint?: string
  image?: string
}

interface Quiz {
  id: string
  title: string
  description: string
  timeLimit: number
  questions: Question[]
  coverImage?: string
}

// Sample quiz data
const sampleQuiz: Quiz = {
  id: "1",
  title: "World Geography Challenge",
  description: "Test your knowledge of world capitals, landmarks, and geographical features.",
  timeLimit: 15, // in minutes
  coverImage: "/placeholder.svg?height=300&width=600",
  questions: [
    {
      question: "What is the capital of France?",
      options: ["London", "Berlin", "Paris", "Madrid"],
      correctAnswer: "Paris",
      hint: "This city is known as the 'City of Light'",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      question: "Which mountain range separates Europe and Asia?",
      options: ["Alps", "Andes", "Himalayas", "Ural Mountains"],
      correctAnswer: "Ural Mountains",
      hint: "These mountains run north to south through Russia",
    },
    {
      question: "Which of these countries is NOT in Africa?",
      options: ["Egypt", "Nigeria", "Bangladesh", "Kenya"],
      correctAnswer: "Bangladesh",
      hint: "This country is located in South Asia",
    },
    {
      question: "What is the largest ocean on Earth?",
      options: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
      correctAnswer: "Pacific Ocean",
      hint: "This ocean covers more than 30% of the Earth's surface",
    },
    {
      question: "Which desert is the largest in the world?",
      options: ["Gobi Desert", "Sahara Desert", "Antarctic Desert", "Arabian Desert"],
      correctAnswer: "Antarctic Desert",
      hint: "This desert is located on a continent that's almost entirely covered in ice",
    },
  ],
}

