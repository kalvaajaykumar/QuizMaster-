"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { BarChart3, Edit, MoreHorizontal, Plus, Trash2, Trophy, Users } from "lucide-react"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("my-quizzes")

  return (
    <div className="container py-10">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Manage your quizzes and view your statistics</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Quizzes Created</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">+2 from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Quiz Completions</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,234</div>
              <p className="text-xs text-muted-foreground">+15% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Average Score</CardTitle>
              <Trophy className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">78%</div>
              <p className="text-xs text-muted-foreground">+5% from last month</p>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:w-auto md:grid-cols-3">
            <TabsTrigger value="my-quizzes">My Quizzes</TabsTrigger>
            <TabsTrigger value="completed">Completed Quizzes</TabsTrigger>
            <TabsTrigger value="stats" className="hidden md:inline-flex">
              Statistics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="my-quizzes" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Quizzes You've Created</h2>
              <Link href="/create">
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Create New Quiz
                </Button>
              </Link>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {myQuizzes.map((quiz) => (
                <Card key={quiz.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle>{quiz.title}</CardTitle>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link href={`/edit/${quiz.id}`} className="flex items-center">
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive focus:text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <CardDescription>{quiz.category}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{quiz.description}</p>
                    <div className="flex items-center gap-2 mt-4">
                      <div className="text-sm text-muted-foreground">{quiz.questionCount} questions</div>
                      <div className="text-sm text-muted-foreground">•</div>
                      <div className="text-sm text-muted-foreground">{quiz.completions} completions</div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Link href={`/quizzes/${quiz.id}`}>
                      <Button variant="outline" size="sm">
                        Preview
                      </Button>
                    </Link>
                    <Link href={`/quizzes/${quiz.id}/results`}>
                      <Button size="sm">View Results</Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Quizzes You've Completed</h2>
              <Link href="/quizzes">
                <Button variant="outline">Find More Quizzes</Button>
              </Link>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {completedQuizzes.map((quiz) => (
                <Card key={quiz.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <CardTitle>{quiz.title}</CardTitle>
                    <CardDescription>{quiz.category}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <div className="text-sm font-medium">Your Score:</div>
                      <div className="text-sm font-bold">{quiz.score}%</div>
                    </div>
                    <div className="flex items-center gap-2 mt-4">
                      <div className="text-sm text-muted-foreground">Completed on {quiz.completedDate}</div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Link href={`/quizzes/${quiz.id}/results`}>
                      <Button variant="outline" size="sm">
                        View Results
                      </Button>
                    </Link>
                    <Link href={`/quizzes/${quiz.id}`}>
                      <Button size="sm">Retake Quiz</Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stats" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Your Statistics</h2>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Performance by Category</CardTitle>
                  <CardDescription>Your average scores across different quiz categories</CardDescription>
                </CardHeader>
                <CardContent className="h-80 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">[Chart visualization would appear here]</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Quiz Activity</CardTitle>
                  <CardDescription>Your quiz creation and completion over time</CardDescription>
                </CardHeader>
                <CardContent className="h-80 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">[Chart visualization would appear here]</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Sample data
const myQuizzes = [
  {
    id: "1",
    title: "World Geography Challenge",
    category: "Geography",
    description: "Test your knowledge of world capitals, landmarks, and geographical features.",
    questionCount: 15,
    completions: 1243,
  },
  {
    id: "2",
    title: "Science Quiz: The Human Body",
    category: "Science",
    description: "Explore the amazing systems and functions of the human body.",
    questionCount: 20,
    completions: 987,
  },
  {
    id: "3",
    title: "History: Ancient Civilizations",
    category: "History",
    description: "Journey through the great ancient civilizations and their contributions.",
    questionCount: 25,
    completions: 756,
  },
  {
    id: "4",
    title: "Pop Culture Trivia 2024",
    category: "Entertainment",
    description: "Stay current with this quiz on the latest trends in movies, music, and more.",
    questionCount: 15,
    completions: 1892,
  },
]

const completedQuizzes = [
  {
    id: "5",
    title: "Coding Concepts for Beginners",
    category: "Technology",
    description: "Learn the basics of programming with this interactive quiz.",
    score: 85,
    completedDate: "Mar 5, 2024",
  },
  {
    id: "6",
    title: "Math Brain Teasers",
    category: "Mathematics",
    description: "Challenge your problem-solving skills with these math puzzles.",
    score: 70,
    completedDate: "Mar 2, 2024",
  },
  {
    id: "7",
    title: "Famous Artists and Their Works",
    category: "Art",
    description: "Test your knowledge of famous artists and their masterpieces throughout history.",
    score: 92,
    completedDate: "Feb 28, 2024",
  },
]

